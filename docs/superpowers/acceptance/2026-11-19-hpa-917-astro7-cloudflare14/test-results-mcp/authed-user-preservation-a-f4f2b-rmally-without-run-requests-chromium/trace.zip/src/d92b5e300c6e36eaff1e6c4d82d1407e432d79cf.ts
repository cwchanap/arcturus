import fs from 'fs';
import path from 'path';
import type { BrowserContext, Page } from '@playwright/test';

// NOTE: This constant is intentionally duplicated in src/lib/e2e-auth-bootstrap.ts.
// The Worker-side plugin (Cloudflare Workers) and this Node-side Playwright helper
// run in separate contexts and must not share imports. Keep both copies in sync —
// they are pinned equal by `bootstrap-secret-header.test.ts`.
export const E2E_BOOTSTRAP_SECRET_HEADER = 'x-e2e-auth-bootstrap-secret';

export type E2eUserCredentials = {
	email: string;
	name: string;
};

function readDevVars(): Record<string, string> {
	const filePath = path.join(process.cwd(), '.dev.vars');
	if (!fs.existsSync(filePath)) return {};

	return Object.fromEntries(
		fs
			.readFileSync(filePath, 'utf8')
			.split(/\r?\n/)
			.map((line) => line.trim())
			.filter((line) => line.length > 0 && !line.startsWith('#'))
			.map((line) => {
				const separatorIndex = line.indexOf('=');
				if (separatorIndex === -1) return [line, ''];
				return [line.slice(0, separatorIndex), line.slice(separatorIndex + 1)];
			}),
	);
}

export function getE2eBootstrapSecret(): string {
	const raw = process.env.E2E_AUTH_BOOTSTRAP_SECRET ?? readDevVars().E2E_AUTH_BOOTSTRAP_SECRET;
	const secret = raw?.trim();
	if (!secret) {
		throw new Error(
			'E2E_AUTH_BOOTSTRAP_SECRET must be set in the environment or .dev.vars for Playwright auth bootstrap',
		);
	}
	return secret;
}

export async function bootstrapTestUser(
	context: BrowserContext,
	baseURL: string,
	credentials: E2eUserCredentials,
): Promise<void> {
	const response = await context.request.post(`${baseURL}/api/auth/e2e/bootstrap`, {
		data: credentials,
		headers: {
			[E2E_BOOTSTRAP_SECRET_HEADER]: getE2eBootstrapSecret(),
			// better-auth >= 1.7 enforces origin checks once a request carries
			// cookies (storageState-loaded contexts do), and Playwright's
			// APIRequestContext sends no Origin header by default.
			Origin: baseURL,
		},
	});

	if (!response.ok()) {
		const body = await response.text().catch(() => '');
		throw new Error(`E2E auth bootstrap failed: ${response.status()} ${body}`);
	}
}

export async function bootstrapPage(
	page: Page,
	baseURL: string,
	credentials: E2eUserCredentials,
): Promise<void> {
	await bootstrapTestUser(page.context(), baseURL, credentials);
	await page.goto(baseURL, { waitUntil: 'domcontentloaded' });
}
